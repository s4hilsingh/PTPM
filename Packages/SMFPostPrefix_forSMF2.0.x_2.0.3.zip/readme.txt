[center][url=http://smftricks.com][img]http://smftricks.com/Themes/SMFHispano/images/theme/logo.png[/img][/url][/center]
[hr]

[center][b][size=14pt]SMF Post Prefix[/size][/b]
[img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img]
[size=8pt]Developed by [url=http://smftricks.com/index.php?action=profile;u=1]Diego Andr�s[/url][/center]

[hr]

[size=12pt][color=red]Introduction[/color][/size]
[size=8pt]SMF Post Prefix mod allows you to set prefixes for your topics and easily customize them with colors.[/size]

[hr]

[size=12pt][color=red]Features[/color][/size]
[list]
[li][size=10pt]Add/Edit prefixes[/size]
[list]
[li][size=9pt]Enable/Disable prefix[/size][/li]
[li][size=9pt]Select a color for the prefix[/size]
[list]
[li][size=8pt]Text color[/size][/li]
[li][size=8pt]Background color[/size][/li]
[li][size=8pt]Use an icon instead of text[/size][/li]
[/list]
[/li]
[li][size=9pt]Select allowed users to use specific prefix[/size]
[list]
[li][size=8pt]Includes support for post count based group[/size][/li]
[li][size=8pt]Includes support for deny groups permissions setting[/size][/li]
[/list]
[/li]
[li][size=9pt]Select boards where the prefix will be usable[/size][/li]
[/list]
[/li]
[li][size=10pt]Select boards where the prefix will be required (forced)[/size][/li]
[li][size=10pt]Permissions[/size]
[list]
[li][size=9pt]Manage prefixes[/size][/li]
[li][size=9pt]Use prefixes (Global permission)[/size][/li]
[/list]
[/li]
[li][size=10pt]Filter Topics by prefix[/size][/li]
[li][size=10pt]Search Topics by prefix[/size][/li]
[/list]

[color=red]*This mod requires at least PHP 5.0[/color]

[hr]

[size=12pt][color=navy][url=http://smftricks.com/index.php?topic=795.0]Changelog[/url][/color][/size]

[hr]

[size=12pt][color=red]License[/color][/size]
[code]This Source Code Form is subject to the terms of the Mozilla Public License, v. 1.1.
If a copy of the MPL was not distributed with this file,
You can obtain one at http://mozilla.org/MPL/

The contents of this package are subject to the Mozilla Public License Version
1.1 (the "License"); you may not use this package except in compliance with
the License. You may obtain a copy of the License at
http://www.mozilla.org/MPL/
 *
Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
for the specific language governing rights and limitations under the
License.[/code]