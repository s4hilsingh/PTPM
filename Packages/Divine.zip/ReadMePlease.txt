Please Note the original smiley author is by David (http://m-panic.blogspot.com/) at icebb.net

http://forums.xaos-ia.com/index.php?profile=1

--
Ported to SMF by shadow82x (www.egadforums.com)


--

Lisence Under: 
http://creativecommons.org/licenses/by-sa/3.0/us/



Enjoy the Smilies. =)
- shadow82x