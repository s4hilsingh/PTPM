<?php
// Rate Topic Uninstall Script

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot UNinstall - please verify you put this in the same place as SMF\'s index.php.');
	
?>