[center][b]rateTopic v1.0[/b][/center]

[b]Description:[/b] Rate a Post based on your forums Message Icons. The Majority vote changes the message icon for the message at hand.

[b]Aim:[/b] To replace the Applaud/Smite Feature of SMF. Based on the work done by Team Gary over at [url=http://www.facepunchstudios.com/]Facepunch Studios[/url]

[b]Note:[/b] Also the message Icons are a little wierd, they don't have any consistent size. At the moment its configured to 16px X 16px. Which makes a few of the icons cramped or misaligned
This can be fixed with appropriate images.
I recommend using something like [url=http://www.somerandomdude.net/srd-projects/bitcons/]Bitcons[/url], just upload the icons to your THEME/images/post/ and add them to your message icons list in SMF Admin

[b]This mod requires Manual theme changes in Custom themes[/b]
[url=http://www.leaderless.net/PackageParser/index.php?file=rateTopic.zip&show=theme][i]Manual Theme Changes[/i][/url]

If you require help, head over to [url=http://www.smfhelper.info/forum/index.php]SMF Helper[/url]