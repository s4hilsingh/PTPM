<?php

//rateTopic Language File
//RateTopic.english.php

$txt['rateTopic'] = array(
	'self_rate' => 'No Self Rate',
	'post_rated' => 'Post Rated',
	'rate_failed' => 'Rate Failed',
	'was_rated' => 'Was Rated:',
	'gave_rated' => 'Gave Rated:',
	'given_by' => 'Given by:',
	'given_to' => 'Given to:'
	);

?>
