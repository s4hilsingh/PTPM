/*
Rate Topic Javascript File
*/

function RateHover( $on, $postid, $name )
{

	if ($on)
	{
		setInnerHTML(document.getElementById('rbt_' + $postid), $name);
	}
	else
	{
		setInnerHTML(document.getElementById('rbt_' + $postid), '');
	}
}

function sendRate( $id, $postid, $sessionId )
{

	if (!window.XMLHttpRequest)
		return;
	if (typeof(window.opera) != "undefined")
	{
		var test = new XMLHttpRequest();
		if (typeof(test.setRequestHeader) != "function")
			return;
	}
	
	
	setInnerHTML(document.getElementById('rb_' + $postid), '<img src="' + rateTopicloader + 'mozilla_blu.gif" alt="Sending..." />');
	//setInnerHTML(document.getElementById('rb_' + $postid), 'Sending...');
	
	var modifyRate = "rateId=" + $id + "&postId=" + $postid + "";
	
	sendXMLDocument(smf_scripturl + '?action=rateTopic;sesc=' + $sessionId + ';xml', modifyRate, on_rateModify);
	
	return false;
}

function on_rateModify(XMLDoc)
{
	if (!XMLDoc)
	{
		return;
	}
	
	var cur_rateMsg = XMLDoc.getElementsByTagName("confirm")[0].childNodes[0].nodeValue;
	var cur_postId = XMLDoc.getElementsByTagName("confirm")[0].getAttribute("id");
	var cur_ratelt = XMLDoc.getElementsByTagName("newrlt")[0].childNodes[0].nodeValue;
	
	setInnerHTML(document.getElementById('rb_' + cur_postId), cur_rateMsg);
	setInnerHTML(document.getElementById('rlt_' + cur_postId), cur_ratelt);
	
}

function getUserRate( $userId)
{

	if (!window.XMLHttpRequest)
		return;
	if (typeof(window.opera) != "undefined")
	{
		var test = new XMLHttpRequest();
		if (typeof(test.setRequestHeader) != "function")
			return;
	}
	
	var getRate = "userId=" + $userId + "";
	
	sendXMLDocument(smf_scripturl + '?action=rateTopic;xml', getRate, on_rateGet);

	return '<div id="sr_'+ $userId + '"><table width="310px" class="windowbg"><tr><td align="center"><img src="' + rateTopicloader + 'loading_sm.gif" alt="Loading..." /></td></tr></table></div>';
}

function on_rateGet(XMLDoc)
{
	
	if (!XMLDoc)
	{
		return;
	}
	
	var cur_rateGet = XMLDoc.getElementsByTagName("divinfo")[0].childNodes[0].nodeValue;
	var cur_userId = XMLDoc.getElementsByTagName("divinfo")[0].getAttribute("id");
	
	setInnerHTML(document.getElementById('sr_' + cur_userId), cur_rateGet);
	tt_FormatTip();
}