<?php
/*******************************************************************************
	This is a simplified script to add settings into SMF.
*******************************************************************************/

// Add Package Servers
db_query("DELETE FROM {$db_prefix}package_servers WHERE url = 'http://www.smfarabic.com/mods'", __FILE__, __LINE__);
db_query("REPLACE INTO {$db_prefix}package_servers (name,url) VALUES ('SmfArabic Mods', 'http://www.smfarabic.com/mods')", __FILE__, __LINE__);


?>