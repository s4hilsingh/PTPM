<?php
/*******************************************************************************
	This is a simplified script to add settings into SMF.
*******************************************************************************/

// Insert SMF Arabic Package Server to list
$request = $smcFunc['db_query']('', '
	SELECT COUNT(*)
	FROM {db_prefix}package_servers
	WHERE name = {string:name}',
	array(
		'name' => 'SmfArabic Mods',
	)
);

list ($count) = $smcFunc['db_fetch_row']($request);
$smcFunc['db_free_result']($request);

if ($count == 0 || $forced)
{
	$smcFunc['db_insert']('insert',
		'{db_prefix}package_servers',
		array(
			'name' => 'string',
			'url' => 'string',
		),
		array(
			'SmfArabic Mods',
			'http://www.smfarabic.com/mods',
		),
		array()
	);
}
?>