<?php
/**
 * @package RSS Images
 * @author digger http://mysmf.net
 * @copyright 2016-2017
 * @license The MIT License (MIT) https://opensource.org/licenses/MIT
 * @version 1.0
 */

$txt['rss_images'] = 'Картинки в RSS';
$txt['rss_images_enabled'] = 'Включить картинки';
$txt['rss_images_quote'] = 'Убирать картинки из цитат';