Mod Information:
Invitation Message [b]In Your Face[/b] (IMIYF)
For SMF 2.0 gold

Invitation Message [b]In Your Face[/b] adds a jquery window message based in jGrowl codes, with a message encouraging to register, and a link to registration.
Only showed to guest / non-logged in members.

You are able to set it up at the smf custom mods section. Time to close, sticky mode, position, texto to show, etc...

By: luuuciano
http://cbasites.net/

[hr]

Hope you like this mod ;)
No cats were killed neither harmed making this mod, anyway I have no idea if Lean or DoctorMalboro did it.

Remember, before to install it... do a backup, as you usual do, right?

Rember2, this mod uses jQuery, you may have conflicts with other javascript libraries, etc... anyway we uses noConflict, trying to avoid it

[hr]

Espero que te agrade este mod ;)
No se ha matado ni lastimado ningún gato haciendo este mod, de todas formas no tengo idea si Lean o DoctorMalboro lo hicieron.

Recuerda, antes de instalarlo... haz un backup, como siempre los haces, ¿no?

Recuerda2, este mod utiliza jQuery, podrías tener conflictos con otras librerías de javascript, etc... de todos modos se usa noConflict, tratando de evitarlos

[hr]
