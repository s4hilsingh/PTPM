[size=13pt][b][color=#404040]Brief Summary:[/color][/b][/size]
[hr]
Powerful & Customizable. Finally, a powerful solution for managing SMF's menu, that is completely customizable!
[hr]

[size=13pt][b][color=#404040]Features:[/color][/b][/size]
[hr][list]
[li]Add Button[list][li]Button Name[/li][li]Button Placement (Before / After | Above / Below)[/li][li]Link Type (Internal Link [dropdown list] | External Link [define URL][/li][li]Target (Self, Parent, Top, Blank)[/li][/list][/li][li]Modify Button[/li][li]Remove Button[/li]
[/list]
Important: In the lite version there is no support for menu items added by modification be it direct hacking of Subs.php, or modifications using hooks. I apologize for the inconvenience.
[hr]

[size=13pt][b][color=#404040]License:[/color][/b][/size]
[hr]
This modification is released under the [url=http://www.mozilla.org/MPL/1.1/index.txt]Mozilla Public License 1.1[/url].

For more information, please visit http://www.mozilla.org/MPL/ or refer to license.txt.
[hr]

[size=13pt][b][color=#404040]Changelog:[/color][/b][/size]
[hr]
[b][color=#404040]v1.0.5 (r3.7.12):[/color][/b]
[list]
[li]! bugfix: second subs.php modification now takes into account the proper version for uninstalling. (!~./modifications.xml)[/li]
[li]! bugfix: the profile button now takes into account default SMF membergroup permissions. (!~./menu_source/resources/main.php)[/li]
[/list]

[hr]
[b][color=#404040]v1.0.4 (r3.7.12):[/color][/b]
[list]
[li]! bugfix: SMF default buttons don't show up to anyone but admins due to permissions. (!~./menu_source/resources/main.php)
Huge thanks to [url=http://www.simplemachines.org/community/index.php?action=profile;u=251953]Yoshi2889[/url] for letting me investigate on his server.[/li]
[li]! bugfix: Undefined error on uninstalling due to package name not being updated in revisions. (!~./modifications.xml)[/li]
[/list]

[hr]
[b][color=#404040]v1.0.3 (r3.6.12):[/color][/b]
[list]
[li]! enhancement: installer utilizes text-strings rather than hard-text to "help multi-lingual forums".[/li]
[/list]

[b][color=#404040]v1.0.2 (r2.17.12):[/color][/b]
[list]
[li]!enhancement: phpDocumentor utilized for all source files. (!./menu_source/*)[/li]
[li]!enhancement: license added to all package files, and license.txt added.[/li]
[/list]

[b][color=#404040]v1.0.1 (r1.16.12):[/color][/b]
[list]
[li]!enhancement: main.js optimized. (!./menu_scripts/main.js)[/li]
[li]!bugfix: script tag syntax typo corrected. (!./menu_source/main.php)[/li]
[li]!bugfix: double quote typo corrected. (!./menu_source/resources/hooks.php)[/li]
[li]!enhancement: multiple "alpha-styled" package headers that were remaining, replaced with proper header comments.[/li]
[li]!bugfix: invalid XHTML from child link IDs starting with an integer resolved. (!./menu_source/resources/main.php x2, !./menu_source/resources/ajax.php)[/li]
[li]!bugfix: not all children listed in placement dropdown. (!./menu_templates/main.template.php)[/li]
[li]!enhancement: on installation, only buttons are added that are not already existing in the menu_items table. (!./resources/menu_db_install.php)[/li]
[li]!bugfix: target, link_type, level, id_parent and has_children default to NULL corrected: should be default = 0 or 1. (!./resources/menu_db_install.php)[/li]
[li]!enhancement: PHP closing tag removed. (!./menu_language/main.english.php)[/li]
[/list]

[b][color=#404040]v1.0.0 (r1.15.12):[/color][/b]
[list]
[li][color=green]+[/color] Initial release![/li]
[/list]
[hr]

[size=13pt][b][color=#404040]Mentions:[/color][/b][/size]
[hr]
[list]
[li]Version: 1.0.5[/li]
[li]jQuery Plugin: [url=http://www.texotela.co.uk/]Int Only Inputs[/url][/li]
[li]Icon Sets: [url=http://p.yusukekamiyamane.com/]Fugue-Icons[/url] & [url=http://led24.de/iconset/]LED-Icons[/url][/li]
[li]Written by: Labradoodle-360[/li]
[li]Copyright: Matthew Kerle - All Rights Reserved[/li]
[li]Dedicated To: LILM[/li]
[/list]
[hr]