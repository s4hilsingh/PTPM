<?php
/**
 * Menu Editor Lite
 *
 * @file menu_ihooks.php
 * @author Matthew Kerle <lab360@simplemachines.org>
 * @copyright Matthew Kerle, 2012
 * @license http://www.mozilla.org/MPL/MPL-1.1.html
 *
 * @version 1.0.5
 */

/**
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is http://www.labradoodle-360.com code.
 *
 * The Initial Developer of the Original Code is
 * Matthew Kerle.
 * Portions created by the Initial Developer are Copyright (C) 2012
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 */
 
// Using SSI?
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<strong>Error:</strong> Cannot install - please make sure that this file in the same directory as SMF\'s SSI.php file.');

// Erm, admins, only.
global $user_info;
if (!$user_info['is_admin'])
	return 'Nice try.';

// Array of Hooks.
$hooks = array(
	'integrate_pre_include' => array(
		'$sourcedir/menu_source/resources/hooks.php'
	),
	'integrate_admin_areas' => array(
		'hook__menu_admin_area'
	)
);

// Add them!
foreach ($hooks as $key => $value)
{
	if (is_array($hooks[$key]))
	{
		foreach ($hooks[$key] as $sValue)
			add_integration_function($key, $sValue);
	}
	else
		add_integration_function($key, $value);
}

// And, we're done!
if (SMF == 'SSI')
	echo 'H00ks Successfully Added!';