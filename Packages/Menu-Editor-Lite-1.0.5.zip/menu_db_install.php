<?php
/**
 * Menu Editor Lite
 *
 * @file menu_db_install.php
 * @author Matthew Kerle <lab360@simplemachines.org>
 * @copyright Matthew Kerle, 2012
 * @license http://www.mozilla.org/MPL/MPL-1.1.html
 *
 * @version 1.0.5
 */

/**
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is http://www.labradoodle-360.com code.
 *
 * The Initial Developer of the Original Code is
 * Matthew Kerle.
 * Portions created by the Initial Developer are Copyright (C) 2012
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 */

// Using SSI?
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<strong>Error:</strong> Cannot install - please make sure that this file in the same directory as SMF\'s SSI.php file.');

// Erm, admins, only.
global $user_info;
if (!$user_info['is_admin'])
	return 'Nice try.';

// We need packages...
if (SMF == 'SSI')
	db_extend('packages');

// Globalize $smcFunc & $scripturl.
global $smcFunc, $scripturl, $txt;

// Here is our table...
$table[] = array(
	'table_name' => '{db_prefix}menu_items',
	'columns' => array(
		array(
			'name' => 'id_button',
			'auto' => true,
			'type' => 'mediumint',
			'size' => 8,
			'null' => true
		),
		array(
			'name' => 'name',
			'auto' => false,
			'type' => 'varchar',
			'size' => 255,
			'null' => true
		),
		array(
			'name' => 'href',
			'auto' => false,
			'type' => 'varchar',
			'size' => 255,
			'null' => true
		),
		array(
			'name' => 'target',
			'auto' => false,
			'type' => 'tinyint',
			'size' => 1,
			'default' => 0,
			'null' => false
		),
		array(
			'name' => 'link_type',
			'auto' => false,
			'type' => 'tinyint',
			'size' => 1,
			'default' => 1,
			'null' => false
		),
		array(
			'name' => 'button_order',
			'auto' => false,
			'type' => 'mediumint',
			'size' => 8,
			'null' => true
		),
		array(
			'name' => 'level',
			'auto' => false,
			'type' => 'tinyint',
			'size' => 1,
			'default' => 0,
			'null' => false
		),
		array(
			'name' => 'id_parent',
			'auto' => false,
			'type' => 'mediumint',
			'size' => 8,
			'default' => 0,
			'null' => false
		),
		array(
			'name' => 'has_children',
			'auto' => false,
			'type' => 'tinyint',
			'size' => 1,
			'default' => 0,
			'null' => false
		)
	),
	'indexes' => array(
		array(
			'columns' => array(
				'id_button'
			),
			'type' => 'primary'
		)
	),
	'if_exists' => 'update',
	'error' => 'fatal',
	'parameters' => array(
	)
);

// Create our tables
foreach ($table as $key => $table)
{
	$smcFunc['db_create_table']($table['table_name'], $table['columns'], $table['indexes'], $table['parameters'], $table['if_exists'], $table['error']);
}

// Add some fluff buttons
$default_buttons = array(
	'home' => array(
		'name' => $txt['home'],
		'href' => '01001001010011000100110001001101',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 1,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 0
	),
	'help' => array(
		'name' => $txt['help'],
		'href' => '?action=help',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 2,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 0
	),
	'search' => array(
		'name' => $txt['search'],
		'href' => '?action=search',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 3,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 0
	),
	'admin' => array(
		'name' => $txt['admin'],
		'href' => '?action=admin',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 4,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 1
	),
	'moderate' => array(
		'name' => $txt['moderate'],
		'href' => '?action=moderate',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 5,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 1
	),
	'profile' => array(
		'name' => $txt['profile'],
		'href' => '?action=profile',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 6,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 1
	),
	'my_messages' => array(
		'name' => $txt['pm_short'],
		'href' => '?action=pm',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 7,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 1
	),
	'calendar' => array(
		'name' => $txt['calendar'],
		'href' => '?action=calendar',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 8,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 1
	),
	'members' => array(
		'name' => $txt['members'],
		'href' => '?action=mlist',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 9,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 1
	),
	'logout' => array(
		'name' => $txt['logout'],
		'href' => '?action=logout',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 10,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 0
	),
	'login' => array(
		'name' => $txt['login'],
		'href' => '?action=login',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 11,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 0
	),
	'register' => array(
		'name' => $txt['register'],
		'href' => '?action=register',
		'target' => 0,
		'link_type' => 1,
		'button_order' => 12,
		'level' => 0,
		'id_parent' => 0,
		'has_children' => 0
	),
	'featuresettings' => array(
		'name' => $txt['modSettings_title'],
		'href' => $scripturl . '?action=admin;area=featuresettings',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 1,
		'level' => 1,
		'id_parent' => 4,
		'has_children' => 0
	),
	'packages' => array(
		'name' => $txt['package'],
		'href' => $scripturl . '?action=admin;area=packages',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 2,
		'level' => 1,
		'id_parent' => 4,
		'has_children' => 0
	),
	'errorlog' => array(
		'name' => $txt['errlog'],
		'href' => $scripturl . '?action=admin;area=logs;sa=errorlog;desc',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 3,
		'level' => 1,
		'id_parent' => 4,
		'has_children' => 0
	),
	'permissions' => array(
		'name' => $txt['edit_permissions'],
		'href' => $scripturl . '?action=admin;area=permissions',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 4,
		'level' => 1,
		'id_parent' => 4,
		'has_children' => 0
	),
	'modlog' => array(
		'name' => $txt['modlog_view'],
		'href' => $scripturl . '?action=moderate;area=modlog',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 1,
		'level' => 1,
		'id_parent' => 5,
		'has_children' => 0
	),
	'poststopics' => array(
		'name' => $txt['mc_unapproved_poststopics'],
		'href' => $scripturl . '?action=moderate;area=postmod;sa=posts',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 2,
		'level' => 1,
		'id_parent' => 5,
		'has_children' => 0
	),
	'attachments' => array(
		'name' => $txt['mc_unapproved_attachments'],
		'href' => $scripturl . '?action=moderate;area=attachmod;sa=attachments',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 3,
		'level' => 1,
		'id_parent' => 5,
		'has_children' => 0
	),
	'reports' => array(
		'name' => $txt['mc_reported_posts'],
		'href' => $scripturl . '?action=moderate;area=reports',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 4,
		'level' => 1,
		'id_parent' => 5,
		'has_children' => 0
	),
	'summary' => array(
		'name' => $txt['summary'],
		'href' => $scripturl . '?action=profile',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 1,
		'level' => 1,
		'id_parent' => 6,
		'has_children' => 0
	),
	'account' => array(
		'name' => $txt['account'],
		'href' => $scripturl . '?action=profile;area=account',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 2,
		'level' => 1,
		'id_parent' => 6,
		'has_children' => 0
	),
	'theme' => array(
		'name' => 'Look and Layout',
		'href' => $scripturl . '?action=profile;area=theme',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 3,
		'level' => 1,
		'id_parent' => 6,
		'has_children' => 0
	),
	'forum_profile' => array(
		'name' => $txt['forumprofile'],
		'href' => $scripturl . '?action=profile;area=forumprofile',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 4,
		'level' => 1,
		'id_parent' => 6,
		'has_children' => 0
	),
	'pm_read' => array(
		'name' => ucwords($txt['pm_menu_read']),
		'href' => $scripturl . '?action=pm',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 1,
		'level' => 1,
		'id_parent' => 7,
		'has_children' => 0
	),
	'pm_send' => array(
		'name' => ucwords($txt['pm_menu_send']),
		'href' => $scripturl . '?action=pm;sa=send',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 2,
		'level' => 1,
		'id_parent' => 7,
		'has_children' => 0
	),
	'view' => array(
		'name' => $txt['calendar_menu'],
		'href' => $scripturl . '?action=calendar',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 1,
		'level' => 1,
		'id_parent' => 8,
		'has_children' => 0
	),
	'post' => array(
		'name' => $txt['calendar_post_event'],
		'href' => $scripturl . '?action=calendar;sa=post',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 2,
		'level' => 1,
		'id_parent' => 8,
		'has_children' => 0
	),
	'mlist_view' => array(
		'name' => ucwords($txt['mlist_menu_view']),
		'href' => $scripturl . '?action=mlist',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 1,
		'level' => 1,
		'id_parent' => 9,
		'has_children' => 0
	),
	'mlist_search' => array(
		'name' => $txt['mlist_search'],
		'href' => $scripturl . '?action=mlist;sa=search',
		'target' => 0,
		'link_type' => 2,
		'button_order' => 2,
		'level' => 1,
		'id_parent' => 9,
		'has_children' => 0
	)
);

// No duplicate buttons, please.
$existing_buttons = array();
$request = $smcFunc['db_query']('', '
	SELECT name, level
	FROM {db_prefix}menu_items
	ORDER BY id_button'
);
while ($button = $smcFunc['db_fetch_assoc']($request))
	$existing_buttons[$button['level']][] = $button['name'];

foreach ($default_buttons as $key => $value)
{
	if (!empty($existing_buttons))
	{
		if (in_array($value['name'], $existing_buttons[$value['level']]))
			continue;
	}
	else
	{
		$smcFunc['db_insert']('insert',
			'{db_prefix}menu_items',
			array(
				'name' => 'string',
				'href' => 'string',
				'target' => 'int',
				'link_type' => 'int',
				'button_order' => 'int',
				'level' => 'int',
				'id_parent' => 'int',
				'has_children' => 'int',
			),
			array(
				$value['name'],
				$value['href'],
				$value['target'],
				$value['link_type'],
				$value['button_order'],
				$value['level'],
				$value['id_parent'],
				$value['has_children'],
			),
			array(
				'id_button'
			)
		);
	}
}

// And, we're done!
if (SMF == 'SSI')
	echo 'Database changes are complete!';