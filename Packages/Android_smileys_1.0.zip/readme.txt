I am not the author of the icons. I just made a package file to make it easier to install!
<br />The icons were made by Google for Android system and are under open-source license.