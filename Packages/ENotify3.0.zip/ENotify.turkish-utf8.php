<?php
// ENotify Language 1.0

// Frontend strings
$txt['notification_feed'] = 'Bildirim Beslemesi';
$txt['notification_generator'] = 'Simple Machines Forum İçin ENotify Modu';
$txt['notification_pm_sent'] = 'sana bir kişisel ileti gönderdi:';
$txt['notification_pm_new'] = 'Yeni Kişisel İleti';
$txt['notification_reply_sent'] = 'şu iletine yanıt yazdı:';
$txt['notification_reply_new'] = 'Yeni İleti Yanıtı';

// Backend strings
$txt['enotify_admin'] = 'ENotify Yönetimi';
$txt['enotify_replies'] = 'Konu yanıt bildirimleri etkin?';
$txt['enotify_pms'] = 'Kişisel ileti bildirimleri etkin?';
$txt['enotify_refresh'] = 'Bildirimler için yenileme aralığı:<div class="smalltext"><strong>Önemli:</strong> Bu değeri çok düşük girmek sunucunuza zarar verir! (Varsayılan: 10000 ms {on saniye})</div>';
$txt['enotify_life'] = 'Bildirimlerin ekranda duracağı süre:';
$txt['enotify_exp'] = 'Kayıt öğelerinin sistemde tutulacağı zaman:';

?>