This mod will add a method by which you can upload images directly to the images folder in the current theme from the Admin control panel. This is displayed in the Themes and Layout section of the Admin CP. From here, you can also upload to any of the sub-folders in the images folder. An upload box is also show in the Membergroups section of the Admin CP to allow one to upload different group "stars" to the images folder.

As well there is a means to quickly change themes. This change is not permanent and the theme selection will revert to the one selected in the user's profile after loging out and then back in again.

Notes:
[list]
[li]Only JPEG, PNG and GIF image formats are allowed.[/li]

[li]Due to the fact that this is designed to replace existing images. There is no overwrite protect or warning if an existing image is overwritten.[/li]

[li]If an existing image is overwritten and does not appear in your browser. Press the Ctrl + F5 keys to refresh the browsers cache.[/li]
[/list]

[hr]
This modification is released under a BSD license, a copy of it with its provisions is included with the package.
[hr]
