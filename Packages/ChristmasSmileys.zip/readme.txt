[center][font=times new roman][size=24pt][color=#654321]Christmas Smileys[/color][/size][/font]
[table]
[tr][td][right][b]Created By:[/b] [/right][/td][td][url=http://www.simplemachines.org/community/index.php?action=profile;u=200419]-=[Vyorel]=-[/url]
([url=http://custom.simplemachines.org/mods/index.php?action=search;author=200419]View my other mods here[/url])[/td][/tr]
[tr][td][right][b]Latest Version:[/b] [/right][/td][td]1.4[/td][/tr]
[tr][td][right][b]My Website[/b] [/right][/td][td][url=https://www.ro-ph.com]Romanian Power Hosting[/url][/td]
[td][url=https://www.truckersmp.ro]TruckersMP Romania[/url][/td][/tr]
[/table]
[/center]

[font=times new roman][size=14pt][color=#654321]Summary[/color][/size][/font]

This package contains 37 Christmas Smileys.

You can install it using the package manager and then use the Smileys and message icons menu (Smileys and Message Icons -> smiley sets new smiley set) to import the smiley's.



[font=times new roman][size=14pt][color=#654321]Disclaimer[/color][/size][/font]
This Avatars are copyrighted to www.freeemoticonsandsmileys.com and all right are reserved.