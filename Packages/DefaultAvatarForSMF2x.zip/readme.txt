If a user's has not selected or uploaded any avatar, then this mod shows a standard avatar on post pages.

Settings to enable it can be found at 
Modification Settings � Miscellaneous.

The default_avatar.png images is located in 
themes\<theme you are using>\images\default_avatar.png

Now with the new version you can simply change the image path through settings panel only. You just have to place the image url and click save, the url image will become default image automatically.