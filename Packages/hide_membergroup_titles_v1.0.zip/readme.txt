[size=12pt][color=blue]Hide Membergroup Titles[/color][/size]

[table]
[tr]
[td][b]Written by:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=182638][b]Labradoodle-360[/b][/url][/td]
[/tr][tr]
[td][b]Additional Author(s):[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=167056]MarcusJ[/url][/td]
[/tr][tr]
[td][b]Current version:[/b] 1.0[/td]
[/tr]
[tr]
[td][b]Updates:[/b] Mod Support Topic[/td]
[/tr]
[tr]
[td][b]Suitable for:[/b] SMF 2.0 RC2, SMF 2.0 RC3[/td]
[/tr]
[tr]
[td][b]Supported languages:[/b] [img]http://www.simplemachines.org/site_images/lang/english.gif[/img][/td]
[/tr]
[tr][td][b]Translators:[/b] Translations are welcome and appreciated![/td][/tr][/table]

[url=http://www.SimpleMachines.org/community]Link to Mod[/url] | [url=https://www.paypal.com/cgi-bin/webscr&cmd=_s-xclick&hosted_button_id=10240245]Donate[/url]

[hr]


[size=12pt][color=blue]Summary[/color][/size]

This mod removes the Member Group title below the user name on topic view.  This is useful on forums when you use member group stars/icons that contain the membergroup title or description in them.  In which case the text above the star/icon become redundant. 

To enable/disable: Configuration > Modification Settings > Miscellaneous > Display Membergroup Titles on Posts
[size=12pt][color=blue]Installation[/color][/size]

[b]Package Manager[/b] should work in most cases. If you need to make any edits, the full list can be obtained from the Parse function on the right..

[b]Useful links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[size=12pt][color=blue]Support[/color][/size]

Questions should be address to the [url=http://www.simplemachines.org/community]mod support topic[/url].

[size=12pt][color=blue]Updating[/color][/size]

Updates will be added here.

[size=12pt][color=blue]Changelog[/color][/size]

[b]1.0[/b] - 03.11.2010
First release of Hide Membergroup Titles

[size=12pt][color=blue]3 Files modified by Hide Membergroup Titles[/color][/size]
./Sources/ManageSettings.php
./Themes/default/Display.template.php
./Themes/default/languages/Modifications.english.php