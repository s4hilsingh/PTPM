<?php

updateSettings(array('show_additional_groups' => '0'));
updateSettings(array('show_additional_groups_name' => '0'));

?>