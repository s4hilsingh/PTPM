[hr]
[center][color=red][size=16pt][b]Display Additional Membergroups[/b][/size][/color][/center]

This MODification allows you to display all the membergroups a user is member of, both in topics view and in profile. You can choose whether or not to show the additional membergroups and, if you choose to show them, whether or not to show the membergroup name (in this case, only the "stars" will be shown)

[b]Languages:[/b]
     - English

[b]Changelog[/b]
[code]
Version 1.04 // 21-10-2014
================================================================================
! Fixed bug: undefined index when deleting a member (thanks DSystem)

Version 1.03 // 02-10-2014
================================================================================
! Fixed bug: undefined index with request to join group (thanks NW Dreamer)
! Fixed bug: groups listing when "show additional membergroups" is NOT selected

Version 1.02 // 01-04-2014
================================================================================
! Fixed bug: conflict with custom profile fields in topic display (thanks Westwegoman)
! Fixed bug: undefined errors in Profile.php (thanks Westwegoman)

Version 1.01 // 22-01-2014
================================================================================
! Fixed minor bug, not showing the post count group stars

Version 1.00 // 23-11-2013
================================================================================
+ First release

Legend:
--------------------------------------------------------------------------------
 ! Minor change or bugfix.
 + Feature addition or improvement.
 - Feature or option removal.
[/code]

[center][img]http://i.creativecommons.org/l/by/3.0/88x31.png[/img]
This mod is licensed under [url=http://creativecommons.org/licenses/by/3.0/]Creative Commons Attribution 3.0 Unported License[/url][/center]