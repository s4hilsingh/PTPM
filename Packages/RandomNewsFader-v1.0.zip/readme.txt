[center][hr][color=blue][size=16pt][b]Random News Fader[/b][/size][size=8pt][b] v1.0[/b][/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?action=profile;u=259685][b]~{By PaulpBaker}~[/b][/url]
[hr][b][url=http://custom.simplemachines.org/mods/index.php?mod=2695]Link to Mod[/url][/b] | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=259685][b]My Mods[/b][/url] | [b][url=http://www.simplemachines.org/community/index.php?topic=396709.0]Support Topic[/url][/b][hr][/center]

[color=blue][b][size=12pt][u]Compatibility[/u][/size][/b][/color]
Version independent so should work on ALL 2.x versions of SMF!

[color=blue][b][size=12pt][u]Description[/u][/size][/b][/color]
Randomized the 'News Fader' to show them in a random order instead of showing them in the order you put them in (1,4,2,5,3 or 4,1,2,5,3 instead of 1,2,3,4,5 etc)

Have some suggestions to make this mod better? Please let me know in the support topic.

[color=blue][b][size=12pt][u]Upcoming Features[/u][/size][/b][/color]
Enable/Disable option in admin settings

[color=blue][b][size=12pt][u]Notes[/u][/size][/b][/color]
You must have 'Show news fader on board index' enabled in 'Administration Center > Configuration > Current Theme' for this to work.

[color=blue][b][size=12pt][u]Installation[/u][/size][/b][/color]
Any previous versions of this mod MUST be uninstalled BEFORE installing this version.

Install the package on the SMF Default 'Curve' Theme ONLY. Other themes will need manual edits.

[b]Useful Links[/b]
[url=http://sleepycode.com/PackageParser/]SMF Package Parser[/url]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[color=blue][b][size=12pt][u]Support[/u][/size][/b][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

[color=blue][b][size=12pt][u]Changelog[/u][/size][/b][/color]
[b]v1.0 - 8th August 2010:[/b] Initial Version