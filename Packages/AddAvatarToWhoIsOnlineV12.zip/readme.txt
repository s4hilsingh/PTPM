[center]
[color=black][size=18pt]Add Avatar To Who Is Online Mod Version 1.1[/size]
Mod By [url=http://www.simplemachines.org/community/index.php?action=profile;u=105299]bolubeyi61[/url]

[b]Screenshot:[/b]
[img]http://img339.imageshack.us/img339/5499/ekranalntshv.png[/img]
[img]http://img688.imageshack.us/img688/2307/66677070.gif[/img]
[img]http://img42.imageshack.us/img42/5277/71571396.gif[/img]

[b]Demo:[/b] 
http://www.spinabifidaturkey.com/smf/index.php?action=who
[/center]
