[center][url=http://www.smfpacks.com][img]http://www.smfpacks.com/imagenes/nuevo_logo_mod.png[/img][/url][/center]

[center][size=5][color=green]Users Online Today by[/color] [url=http://www.smfpacks.com][color=green]SMFPacks.com[/color][/url][/size][/center]

[b]Creator:[/b]

Originally created by [url=http://www.simplemachines.org/community/index.php?action=profile;u=30615]Carceri[/url]

[b]Developer:[/b]

[url]www.smfpacks.com[/url]

[b]Important Info:[/b]

This Mod is developer by SMFPacks.com - The #1 Website for the Customziation of your SMF. SMFPacks.com Provides Other Great Packages:

- Reason for Editing Mod.
- Yet Another Global Announcements Mod.
- SMF Social Groups.
- SMF Links Directory.
- SMF Downloads Directory.
- SMF Dynamic Directory.
- Advanced Topic Prefix Mod.
- Advanced Invitations System.
- Move Topic Notification.
- PM to New Members.
- Permissions Info.
- Next Post Level.
- Karma Buttons.
- SMF Multi Quote.
- Attachments in Topics.
- and much more visit us on SMFPacks.com

[b]Description:[/b]

Adds a list of all users that were online on the current day to the 'Info Center'. This is a simple mod that does the job and not a whole lot more. I like to keep it simple.

[b]Features:[/b]
- By hovering the cursor over the username, it will display when the user was last logged in
- The time period that the user list shows can be the current day, last 24 hours or last week
- The list can be sorted in various ways
- Viewing of the list can be restricted

It modifies files in the default theme, so if you are using any other theme you need to make changes to your theme files. I offer no support for this.

[b]Upgrading:[/b]

Just uninstall whatever version you've installed and install the latest one.

[b]Languages:[/b]

- Croatian.
- Danish.
- Dutch.
- English.
- Finnish.
- German.
- Hungarian.
- Persian.
- Portuguese.
- Russian.
- Serbian.
- Spanish.
- Turkish.