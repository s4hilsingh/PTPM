
Thankyou for chosing to use MSN Icons. Please do not redistribute these smilies without permission. Permission can be granted by contacting Peludo_08 at www.tu-rincon.com/ so please allow time for an answer. Also requests can be made via the forum for that website.



Enjoy your new smilies :)





