[size=12pt][color=#70A2FF][b]Email Template Editor[/b][/color][/size]

[hr][b]Author: [url=http://www.simplemachines.org/community/index.php?action=profile;u=182638]Labradoodle-360[/url][/b]
[b]Latest Version:[/b] 1.0
[b]Compatible With SMF:[/b] 2.0 RC4, 2.0 RC5
[b]Special Thanks To:[/b] Bigguy & Scotty
[b]Dedicated To:[/b] LIM[hr]


[hr][size=12pt][color=#70A2FF]Summary[/color][/size][hr]
Email Template Editor [b]finally[/b] provides SMF Admins with the ability to modify the SMF emails that are sent out by default right through your admin panel, without having to touch ANY files.

Here are some things it can do.
[list]
[li]Create Custom Template - Based on any of the 52 SMF Default Emails.[/li]
[li]Modify Custom Template - Allowing you to modify your custom templates, after you have created them![/li]
[li]Remove Custom Template - Want to go back to the SMF default template for that email? Simply delete it, OR leave the fields empty.[/li]
[li]Testing Ability - Want to test your custom template(s) to see what they'll look like in action? Here you go.[/li]
[/list]
And more!

In addition, there are NO template edits required for this mod.

Icon Set: [url=http://www.famfamfam.com/lab/icons/silk/]FamFamFam Silk Icons[/url].
[hr]


[hr][size=12pt][color=#70A2FF]Languages[/color][/size][hr]
[img]http://www.simplemachines.org/site_images/lang/english.gif[/img]
[hr]


[hr][size=12pt][color=#70A2FF]Installation[/color][/size][hr]
[b]Package Manager[/b] should work in most cases. If you need to make any edits, the full list can be obtained from the Parse function on the right.

[b]Useful links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]
[hr]


[hr][size=12pt][color=#70A2FF]Version 1.0 Changelog[/color][/size][hr]
[b][color=green]+[/color][/b]) Create Custom Email Template - Based off of any SMF Default Email.
[b][color=green]+[/color][/b]) Modify Custom Email Templates.
[b][color=green]+[/color][/b]) Remove Custom Email Templates.
[b][color=green]+[/color][/b]) Use all global preset variables in custom Email Templates.
[b][color=green]+[/color][/b]) Send Test Emails - Selecting any custom template, and inputting a recipient email address.
[hr]


[hr][size=12pt][color=#70A2FF]Files modified by Email Template Editor 1.0[/color][/size][hr]
[b]SMF 2.0 RC3, SMF 2.0 RC4[/b]
[b][i]Source Files (./Sources)[/i][/b]
[list]
[li]Admin.php[/li]
[li]Subs-Post.php[/li]
[li][b][color=green]+[/color][/b]) EmailTemplateEditor.php[/li]
[li][b][color=green]+[/color][/b]) Subs-EmailTemplateEditor.php[/li]
[/list]
[b][i]Template Files (./Themes/default)[/i][/b]
[list]
[li][b][color=green]+[/color][/b]) EmailTemplateEditor.template.php[/li]
[/list]
[b][i]Language Files (./Themes/default/languages)[/i][/b]
[list]
[li]Modifications.english.php[/li]
[li][b][color=green]+[/color][/b]) EmailTemplateEditor.english.php[/li]
[/list]
[b][i]Image Files (./Themes/default/images)[/i][/b]
[list]
[li][b][color=green]+[/color][/b]) /admin/application_view_tile.png
[li][b][color=green]+[/color][/b]) /email_templates[list][li][li][b][color=green]+[/color][/b]) accept.png - famfamfam[/li][li][b][color=green]+[/color][/b]) add.png - famfamfam[/li][li][b][color=green]+[/color][/b]) cross.png - famfamfam[/li][li][b][color=green]+[/color][/b]) delete.png - famfamfam[/li][li][b][color=green]+[/color][/b]) pencil.png - famfamfam[/li][/list][/li]
[/list]
[hr]


[hr][url=]Link to Mod[/url] | [url=https://www.paypal.com/cgi-bin/webscr&cmd=_s-xclick&hosted_button_id=10240245]Support Labradoodle-360's Development[/url][hr]