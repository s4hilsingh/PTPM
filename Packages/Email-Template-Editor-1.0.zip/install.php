<?php
// Labradoodle-360; Email Template Editor - install.php

// Using SSI?
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<strong>Error:</strong> Cannot install - please make sure that this file in the same directory as SMF\'s SSI.php file.');

// We need packages...
if (SMF == 'SSI')
	db_extend('packages');

// Globalize what we need...
global $smcFunc;

// Here is our table...
$table = array(
	'table_name' => '{db_prefix}email_templates',
	'columns' => array(
		array('name' => 'id_template', 'auto' => false, 'type' => 'varchar', 'size' => 255, 'null' => true),
		array('name' => 'subject', 'auto' => false, 'type' => 'varchar', 'size' => 255, 'null' => true),
		array('name' => 'body', 'auto' => false, 'type' => 'text', 'size' => 65535, 'null' => true)
	),
	'indexes' => array(
		array('columns' => array('id_template'), 'type' => 'primary')
	),
	'if_exists' => 'update',
	'error' => 'fatal',
	'parameters' => array(),
);

// Create our table.
$smcFunc['db_create_table']($table['table_name'], $table['columns'], $table['indexes'], $table['parameters'], $table['if_exists'], $table['error']);

// And, we're done!
if (SMF == 'SSI')
	echo 'Database changes are complete!';

?>