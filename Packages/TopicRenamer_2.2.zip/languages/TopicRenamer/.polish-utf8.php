<?php

global $txt;

$txt['rename_topic'] = 'Zmień tytuł wątku';
$txt['permissionname_rename_topic'] = 'Zmiana tytułu wątku';
$txt['permissionname_rename_topic_own'] = 'Własny wątek';
$txt['permissionname_rename_topic_any'] = 'Dowolny wątek';
$txt['permissionname_simple_rename_topic_own'] = 'Zmiana tytułu własnego wątku';
$txt['permissionname_simple_rename_topic_any'] = 'Zmiana tytułu dowolnego wątku';
$txt['rename_topic_no_id'] = 'Musisz wybrać poprawny wątek.';
$txt['rename_topic_subject'] = 'Tytuł wątku';

?>