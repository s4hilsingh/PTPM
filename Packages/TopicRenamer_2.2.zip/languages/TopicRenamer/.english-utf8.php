<?php

global $txt;

$txt['rename_topic'] = 'Rename Topic';
$txt['permissionname_rename_topic'] = 'Rename Topic';
$txt['permissionname_rename_topic_own'] = 'Own Topic';
$txt['permissionname_rename_topic_any'] = 'Any Topic';
$txt['permissionname_simple_rename_topic_own'] = 'Rename Own Topic';
$txt['permissionname_simple_rename_topic_any'] = 'Rename Any Topic';
$txt['rename_topic_no_id'] = 'You must select a valid topic.';
$txt['rename_topic_subject'] = 'Topic Subject';

?>