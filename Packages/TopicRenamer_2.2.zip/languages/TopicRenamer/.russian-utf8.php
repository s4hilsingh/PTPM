<?php

global $txt;

$txt['rename_topic'] = 'Переименовать тему';
$txt['permissionname_rename_topic'] = 'Переименование темы';
//$txt['permissionhelp_rename_topic'] = 'Позволяет пользователям легко переименовывать темы в два клика мыши.';
$txt['permissionname_rename_topic_own'] = 'Собственная тема';
$txt['permissionname_rename_topic_any'] = 'Любая тема';
$txt['permissionname_simple_rename_topic_own'] = 'Переименование своей темы';
$txt['permissionname_simple_rename_topic_any'] = 'Переименование любой темы';
$txt['rename_topic_no_id'] = 'Вы должны выбрать существующую тему.';
$txt['rename_topic_subject'] = 'Название темы';

?>