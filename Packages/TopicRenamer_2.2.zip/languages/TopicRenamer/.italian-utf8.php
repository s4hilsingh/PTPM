<?php

global $txt;

$txt['rename_topic'] = 'Rinomina Topic';
$txt['permissionname_rename_topic'] = 'Rinomina Topic';
$txt['permissionname_rename_topic_own'] = 'Proprio Topic';
$txt['permissionname_rename_topic_any'] = 'Qualsiasi Topic';
$txt['permissionname_simple_rename_topic_own'] = 'Rinomina il Proprio Topic';
$txt['permissionname_simple_rename_topic_any'] = 'Rinomina Qualsiasi Topic';
$txt['rename_topic_no_id'] = '� necessario selezionare un topic valido.';
$txt['rename_topic_subject'] = 'Oggetto del Topic';

?>