﻿<?php

global $txt;

$txt['rename_topic'] = 'Промени Наслов Теме';
$txt['permissionname_rename_topic'] = 'Промени Наслов Теме';
$txt['permissionname_rename_topic_own'] = 'Своја Тема';
$txt['permissionname_rename_topic_any'] = 'Било која Тема';
$txt['permissionname_simple_rename_topic_own'] = 'Промени наслов Своје Теме';
$txt['permissionname_simple_rename_topic_any'] = 'Промени наслов Било које Теме';
$txt['rename_topic_no_id'] = 'Морате изабрати важећу тему.';
$txt['rename_topic_subject'] = 'Наслов Теме';

?>