﻿<?php

global $txt;

$txt['rename_topic'] = 'Promeni Naslov Teme';
$txt['permissionname_rename_topic'] = 'Promeni Naslov Teme';
$txt['permissionname_rename_topic_own'] = 'Svoja Tema';
$txt['permissionname_rename_topic_any'] = 'Bilo koja Tema';
$txt['permissionname_simple_rename_topic_own'] = 'Promeni naslov Svoje Teme';
$txt['permissionname_simple_rename_topic_any'] = 'Promeni naslov Bilo koje Teme';
$txt['rename_topic_no_id'] = 'Morate izabrati važeću temu.';
$txt['rename_topic_subject'] = 'Naslov Teme';

?>