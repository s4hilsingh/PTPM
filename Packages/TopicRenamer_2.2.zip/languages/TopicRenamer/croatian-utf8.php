﻿<?php

global $txt;

$txt['rename_topic'] = 'Promjeni Naslov Teme';
$txt['permissionname_rename_topic'] = 'Promjeni Naslov Teme';
$txt['permissionname_rename_topic_own'] = 'Vlastita Tema';
$txt['permissionname_rename_topic_any'] = 'Bilo koja Tema';
$txt['permissionname_simple_rename_topic_own'] = 'Promjeni naslov Vlastite Teme';
$txt['permissionname_simple_rename_topic_any'] = 'Promjeni naslov Bilo koje Teme';
$txt['rename_topic_no_id'] = 'Morate izabrati važeću temu.';
$txt['rename_topic_subject'] = 'Naslov Teme';

?>