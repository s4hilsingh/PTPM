<?php

global $txt;

$txt['rename_topic'] = 'Zmie� tytu� w�tku';
$txt['permissionname_rename_topic'] = 'Zmiana tytu�u w�tku';
$txt['permissionname_rename_topic_own'] = 'W�asny w�tek';
$txt['permissionname_rename_topic_any'] = 'Dowolny w�tek';
$txt['permissionname_simple_rename_topic_own'] = 'Zmiana tytu�u w�asnego w�tku';
$txt['permissionname_simple_rename_topic_any'] = 'Zmiana tytu�u dowolnego w�tku';
$txt['rename_topic_no_id'] = 'Musisz wybra� poprawny w�tek.';
$txt['rename_topic_subject'] = 'Tytu� w�tku';


?>