This mod integrates image hosting with SMF. It makes image upload very simple.
All images are hosted on remote image hosting service, not on your forum.
When user uploads image, script creates a thumbnail for image and appends bbcode to post user is typing.
User doesn't need to know anything about bbcode. And this mod is very simple to install.

Powered by [url=http://imgbb.com/mod]imgbb.com[/url]